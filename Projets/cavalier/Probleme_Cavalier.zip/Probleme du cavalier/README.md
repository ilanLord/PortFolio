Projet SAE 2.02
Parcours d'un cavalier sur les cases d'un échiquier

Utilisation du parcours de graphe hamiltonien

parcoursSeul.py -> Renvoie le chemin du parcours d'un cavalier passant par toutes les cases sans repasser 2x sur la même. Il n'affiche qu'un seul chemin possible si il y en a un.

parcoursPlusieurs.py -> Renvoie la totalité des chemins possibles pour le parcours du cavalier à partir d'une case.

main.py -> Affichage Graphique du premier chemin possible du problème du cavalier. Affiche sur le côté le nombre de chemin possible. Affiche un message d'erreur si aucun chemin n'est possible.

calculCPU.py -> Affiche le temps que prend les deux programmes de parcours avec l'heuristique et sans. (heuristique = méthode pour aller plus rapidement)