#include <stdlib.h>
#include <stdio.h>
#include <string.h>

//déclaration des constantes
const int ARRET=-1; //initialisation de la valeur d'arret

int main(){
   	//déclaration des variables
	int n;
    int sommeN;
    float moyN;
    int nbN; 

    nbN = 0; 
    sommeN = 0;


   	// saisie des données
	printf("Valeur: "); //on demande la valeur à saisir
    scanf("%d",&n);
    while (n!=-1) {
        nbN++; //on ajoute 1 au nombre de note entré puis on ajoute à la somme la valeur
        sommeN += n;
        printf("Valeur: ");
        scanf("%d",&n);
    }
	
   	// traitement des données
	if (nbN == 0) {
        printf("Aucune note entrée ! Aucune moyenne !\n"); //on vérifie qu'il y ait au moins une note entrée sinon on affiche qu'il n'y aucune moyenne
    } else {
        moyN = 1.0*sommeN/nbN; //on calcul la moyenne puis on l'affiche 
        printf("La moyenne est de %.2f !\n",moyN);
    }	
	
   	return EXIT_SUCCESS;
}
