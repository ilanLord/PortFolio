#include <stdlib.h>
#include <stdio.h>
#include <string.h>

//       1  2  3    4  5  6    7  8  9 
//     ---------------------------------
// 1   | 5  3  . || .  7  . || .  .  . | 
// 2   | 6  .  . || 1  9  5 || .  .  . |
// 3   | .  9  8 || .  .  . || .  6  . |
//     ---------------------------------
// 4   | 8  .  . || .  6  . || .  .  3 | 
// 5   | 4  .  . || 8  .  3 || .  .  1 |
// 6   | 7  .  . || .  2  . || .  .  6 |
//     ---------------------------------
// 7   | .  6  . || .  .  . || 2  8  . | 
// 8   | .  .  . || 4  1  9 || .  .  5 |
// 9   | .  .  . || .  8  . || .  7  9 |
//     ---------------------------------


int main() {
    int test;
    int test2;
    int test3;
    printf("      1  2  3    4  5  6    7  8  9 \n");
    printf("    ---------------------------------\n");
    printf("1   | 5  3  . || .  7  . || .  .  . |\n");
    printf("2   | 6  .  . || 1  9  5 || .  .  . |\n");
    printf("3   | .  9  8 || .  .  . || .  6  . |\n");
    printf("    ---------------------------------\n");
    printf("4   | 8  .  . || .  6  . || .  .  3 |\n");
    printf("5   | 4  .  . || 8  .  3 || .  .  1 |\n");
    printf("6   | 7  .  . || .  2  . || .  .  6 |\n");
    printf("    ---------------------------------\n");
    printf("7   | .  6  . || .  .  . || 2  8  . |\n");
    printf("8   | .  .  . || 4  1  9 || .  .  5 |\n");
    printf("9   | .   .  . || .  8  . || .  7  9 |\n");
    printf("    ---------------------------------\n");
    printf("\nColonne de la saisie: ");
    scanf("%d",&test);
    printf("Ligne de la saisie: ");
    scanf("%d",&test);
    printf("Numéro à saisir: ");
    scanf("%d",&test);
    printf("Erreur ! Impossible de remplacer une valeur de la grille d'origine !\n");
    return EXIT_SUCCESS;
}
