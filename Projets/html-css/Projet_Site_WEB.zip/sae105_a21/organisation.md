# Organisation générale
- [Pages](#pages)
  - [HTML](#html)
  - [CSS](#css)

## Pages
### HTML 
- index.html > Igor
- backstage.html > Ilan
- critiques.html > Igor
- compte.html > Maxime
- episodes.html > Yoan

### CSS 
- Mode clair > Maxime
- Mode sombre > Ilan
- responsive design + media queries > Yoan
- feuilles spécifiques :
    - index.css > Igor
    - backstage.css > Ilan
    - critiques.css > Igor
    - compte.css > Maxime
    - episodes.css > Yoan

## Composants spécifiques
Toggle clair/sombre : Igor/Ilan